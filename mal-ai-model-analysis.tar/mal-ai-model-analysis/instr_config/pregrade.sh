#!/bin/bash
#
# pregrade.sh - chay tren container cham diem, truoc ResultParser.
#   $1 = thu muc home cua grader
#   $2 = <email>.<lab>/<container> (thu muc home da giai nen cua sinh vien)
#
# Chuan hoa ~/result.txt cua sinh vien giong grade.py (lab_build):
#   - chi lay cac dong dang TEN_TRUONG=gia_tri (bo comment, dong trong)
#   - gia tri: bo moi khoang trang/tab/CR, chuyen chu thuong
# Ket qua ghi vao .local/result/result_norm.txt, results.config doc file nay.
#
homedir=$1
destdir=$2
cd "$homedir/$destdir" || exit 0

outdir=.local/result
mkdir -p "$outdir"
out=$outdir/result_norm.txt
: > "$out"

if [ -f result.txt ]; then
    awk '
    {
        sub(/\r$/, "")
        line = $0
        if (line ~ /^[ \t]*#/) next
        eq = index(line, "=")
        if (eq == 0) next
        k = substr(line, 1, eq - 1)
        v = substr(line, eq + 1)
        gsub(/[ \t\r]/, "", k)
        if (k !~ /^[A-Z][A-Z0-9_]*$/) next
        gsub(/[ \t\r]/, "", v)
        print k "=" tolower(v)
    }' result.txt > "$out"
fi
exit 0
